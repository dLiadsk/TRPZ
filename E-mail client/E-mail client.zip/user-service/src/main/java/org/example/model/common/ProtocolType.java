package org.example.model.common;

public enum ProtocolType {
    IMAP,
    POP3,
    SMTP;
}
