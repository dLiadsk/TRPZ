package org.example.repository.entity.common;

public enum EmailStatus {
    READ, SENT, UNREAD, DRAFT, DELETED
}
