package org.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FolderServiceMain {
    public static void main(String[] args) {
        SpringApplication.run(FolderServiceMain.class, args);
    }
}