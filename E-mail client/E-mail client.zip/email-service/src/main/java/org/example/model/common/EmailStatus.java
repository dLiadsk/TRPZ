package org.example.model.common;

public enum EmailStatus {
    READ, SENT, UNREAD, DRAFT, DELETED
}
