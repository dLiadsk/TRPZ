package org.example.service.mapper;

import org.example.model.EmailAccount;
import org.example.model.ServerConnection;
import org.example.model.common.ProtocolType;
import org.example.service.dto.EmailAccountDto;
import org.example.service.dto.ServerConnectionDto;

public class EmailAccountMapper {

}
