package org.example.common;

public enum EmailStatus {
    READ, SENT, UNREAD, DRAFT, DELETED
}
