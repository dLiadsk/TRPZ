package com.example.appmodule.config;

public enum EmailStatus {
    READ, SENT, UNREAD, DRAFT, DELETED
}
